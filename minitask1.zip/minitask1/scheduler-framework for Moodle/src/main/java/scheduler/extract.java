package main.java.scheduler;

import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.TreeMap;

public class extract {
    private Map<RT, Set<String>> operations;
    private Map<String, Set<RT> > res;
    private Map<RT, Integer> operationssize;
    
    // 使用一个 Map 来存储被移除的节点及其恢复时间
    private Map<String, Integer> usingMap = new HashMap<>();
    // 定义 resschedule，用来存储恢复时间点和对应的资源
    private Map<Integer, String> resschedule = new HashMap<>();
    // 存储 <Node, upboundTimestep> 的映射
    private Map<Node, Integer> nodeUpboundTimestepMap = new HashMap<>();

    
   
    //每次迭代得到的schedule存储到map之中，最终return时返回delay最小的那个

    private Map<Integer, Schedule> scheduleMap = new HashMap<>();
     // 存储深度拷贝后的 Map
    private Map<String, Set<RT>> nowRes = new HashMap<>();
    private Map<RT, Set<String>> nowOperations = new HashMap<>();
    private Map<RT, Integer> nowOperationsSize = new HashMap<>();




    public Schedule generateStatistics(Graph graph, RC rc) {
   
    
    Map<String, Set<RT>> allResources = rc.getAllRes();//get instance of RC
    
    int delay=0;

    res=rc.getAllRes();
    operations=rc.getOperations();
    //res = new TreeMap<String, Set<RT>>();
    //operations = new TreeMap<RT, Set<String>>();
    operationssize=getOperationsSize(operations);//the original data of size
    

    
    

    

   



    // 1. 创建一个队列存储入度为 0 的节点，计算interval

    /*     double w1 = 1.0;  // 资源权重
    double w2 = 1.5;  // 出度的权重
    double w3 = 2.0;  // 关键路径长度的权重*/



   double w1=-3.596802584171183;
   double w2=1;
   double w3=1;

    
    // 设置 epoch 数量
    int epoch = 1;
    
    // 高斯分布的标准差，控制扰动的范围
    double stdDev = 1;
    // 使用 Random 生成高斯分布的随机数
    Random random = new Random();
    Schedule schedule = new Schedule();

    // 模拟 epoch 循环
    for (int i = 0; i < epoch; i++) {
        resetResourcesAndOperations();
        schedule=new Schedule();
        int nodeCount = graph.size();
        //System.out.printf("epoch: %d, nodeCount: %d\n", i, nodeCount);
        graph.reset();

        //最大的循环
        // 对每个权重值进行高斯化扰动
        w1 += random.nextGaussian() * stdDev;  // 高斯扰动
        w2 += random.nextGaussian() * stdDev;  // 高斯扰动
        w3 += random.nextGaussian() * stdDev;  // 高斯扰动

        // 输出每个 epoch 后的权重
        //System.out.printf("Epoch %d: w1 = %.2f, w2 = %.2f, w3 = %.2f\n", i + 1, w1, w2, w3);
    
        int loopdetect=0;
        int timestep=0;


    //调度循环开始
    while (nodeCount > 0) {
        //loopdetect++;
        //if(loopdetect>100){break;}
        int graphtimes=0;
        Map<Node, Interval> zeroInDegreeQueue = new HashMap<Node, Interval>();
        Map<Node, Interval> Nodeinterval = new HashMap<Node, Interval>();
        Map<Node, Double> nodePriorities = new HashMap<>();

        if (usingMap != null && !usingMap.isEmpty()) {
            restoreResources(timestep);
            //System.out.printf("res restored");
        }
        if(nodeUpboundTimestepMap!= null &&!nodeUpboundTimestepMap.isEmpty()){
        processNodesBeforeTimestep(timestep);
        }

        
        
    // 遍历节点，得到当前可运行节点(0 indegree)
        for (Node node : graph) {
            
             //小循环入口，上面应该加循环，直到graph中已经没有未处理节点
             graphtimes++;
             //System.out.print(node.isProcessed());




        // 3. 如果节点的入度为 0，则加入队列。get root node
            // 假设你有一个图，其中任务A和B依赖于SLACK节点
            if(!node.isProcessed()){
                //如果该节点尚未被处理
                if (node.predecessors().size() == 0) {
                    if (node.getDelay() > 0) {  // 只有非SLACK节点有实际延迟
                        zeroInDegreeQueue.put(node, new Interval(timestep, timestep + node.getDelay() - 1));
                        Nodeinterval.put(node, new Interval(timestep, timestep + node.getDelay() - 1));
                        delay=Math.max(timestep + node.getDelay() - 1,timestep);
                        //delay=timestep;
                        //System.out.printf("0 degree node detected ");
                    } else {
                        // 对于SLACK节点，不消耗时间，因此直接在调度中跳过其时间消耗
                        zeroInDegreeQueue.put(node, new Interval(timestep, timestep));  // 没有延迟
                        Nodeinterval.put(node, new Interval(timestep, timestep));
                    }
                }
            }
            else{
            }
        }

        Iterator<Node> iterator = zeroInDegreeQueue.keySet().iterator();  // 获取迭代器

        while (iterator.hasNext()) {
            Node node = iterator.next();  // 获取当前节点
            
            // 对所有入度为 0 的节点计算优先级
            int outDegree = node.successors().size();   // 出度
            int critilength = node.getCriticalPathLength();  // 关键路径长度
            RT needres = node.getRT();

            // just deal with operations and operationssize
            double rescore = 0.0;
            if (nowOperationsSize.get(needres) != 0) {
                double orirescore = ((double) operationssize.get(needres) + 1) / ((double) nowOperationsSize.get(needres) + 1);

                rescore = scaleScore(orirescore, (double) operationssize.get(needres) + 1);
            } else {
                // 一个资源数值为 0 要将它移除 zero
                iterator.remove();  // 安全地移除当前元素
                //System.out.printf(node.id + " donot have res");
            }

            // 根据调度标准计算每个节点的优先级
            double score = w1 * rescore + w2 * outDegree + w3 * critilength;

            // 为节点分配优先级
            nodePriorities.put(node, score);  // 存储节点及其计算的优先级分数
        }
        // 在遍历之前，准备一个临时Map来保存操作
        Map<RT, Integer> tempOperationsSize = new HashMap<>(nowOperationsSize);


    

        zeroInDegreeQueue.clear();



    
      // 将 nodePriorities 中的节点按 score 降序排序
    List<Map.Entry<Node, Double>> sortedEntries = new ArrayList<>(nodePriorities.entrySet());

    // 使用匿名内部类定义一个 Comparator 按照 score 降序排序
    sortedEntries.sort(new Comparator<Map.Entry<Node, Double>>() {
        @Override
        public int compare(Map.Entry<Node, Double> entry1, Map.Entry<Node, Double> entry2) {
            return Double.compare(entry2.getValue(), entry1.getValue());  // 降序排序
        }
    }
    );
    nodePriorities.clear();
    int proces=0;
    // 遍历排序后的节点并处理

    for (Map.Entry<Node, Double> entry : sortedEntries) {
        //System.out.printf("%d", sortedEntries.size());
        //System.out.printf("processorder:%d", proces);
        //proces++;

        Node node = entry.getKey();
        double score = entry.getValue();

        // 打印当前节点的最高分数
        //System.out.println("Processing Node with score: " + score);

        // 资源检查
        if (nowOperationsSize.get(node.getRT()) > 0) {
            Interval slot = Nodeinterval.get(node);
        
            // 调度该节点
            schedule.add(node, slot);
            //System.out.printf("node:" + node.id + " processed");
            //System.out.printf("RT reamin:" +nowOperationsSize.get(node.getRT()));
        
            // 标记节点为已处理
            node.markAsProcessed();

            nodeUpboundTimestepMap.put(node, slot.getubound());

            //这个，似乎应该要处理
            /* for (Node nd : node.successors()) {
                // 移除节点作为其他节点的前继
                nd.remove(node);
            }*/
            
        
            // 资源调度
            String usedRes = selectResourceForRT(node.getRT());
        
            // 表明资源何时将重新可用
            resschedule.put(slot.getubound() + 1, usedRes);
        
            // 从 operations 中移除选中的资源
            for (Map.Entry<RT, Set<String>> resEntry : nowOperations.entrySet()) {
                Set<String> resourceSet = resEntry.getValue();
                resourceSet.remove(usedRes);  // 从资源集合中移除被选中的资源
            }
        
            // 从 nowRes 中移除选中的资源
            nowRes.remove(usedRes);  // 从资源列表中移除选中的资源
            storeResourceToUsingMap(usedRes, slot.getubound() + 1);
        
            
            // 更新 nowOperationsSize：减少对应资源的操作数
            /* 
            RT rt = node.getRT();  // 获取节点的 RT
            if (nowOperationsSize.containsKey(rt)) {
                int updatedOperationsCount = nowOperationsSize.get(rt) - 1;  // 减少操作数
                nowOperationsSize.put(rt, updatedOperationsCount);  // 更新 map 中的值
            }
            */
            // 同时，检查此资源是否支持其他操作，如果支持，减少这些操作的资源数量
            for (Map.Entry<RT, Set<String>> resEntry : nowOperations.entrySet()) {
                RT supportedRT = resEntry.getKey();
                Set<String> resources = resEntry.getValue();

                // 如果资源仍然在支持的操作集合中，减少这些操作的资源数量
                
                int updatedCount = nowOperationsSize.get(supportedRT) - 1;
                nowOperationsSize.put(supportedRT, updatedCount);
                
            }
        
            nodeCount--;  // 节点处理计数减1
        
            
                //System.out.printf("nodeCount--: %d\n", nodeCount);  // 输出当前的 nodeCount
            
        } else {
            // 如果没有空闲资源，则移除该节点
            nodePriorities.remove(node);
        }
         
    
    }
    // 遍历结束后更新原始 Map
    

    // 将所有小于0的值改为0
    for (Map.Entry<RT, Integer> entry : nowOperationsSize.entrySet()) {
        if (entry.getValue() < 0) {
            entry.setValue(0);  // 如果值小于0，则将其设置为0
        }
    }
    timestep++;  // 当前0前继节点处理完毕，递增时间步
    //System.out.println("go to next time step."+timestep);
    sortedEntries.clear();

// 如果所有节点已经调度完毕
        if (nodeCount == 0) {
            //System.out.printf("All nodes have been processed.");
            
        } 


    //while loop
    }
    //System.out.printf("epoch:"+i);
    writeOutputToFile(w1, w2, w3, delay);
    //0:

    //epoch loop
    
}
return schedule;

}




private void writeOutputToFile(double w1, double w2, double w3, int delay) {
    // 创建 CSV 格式的输出字符串
    String output = w1 + "," + w2 + "," + w3 + "," + delay;
    //System.out.println("w1: " + w1 + ", w2: " + w2 + ", w3: " + w3 + ", delay: " + delay);
    System.out.println(w1 + ", " + w2 + ", " + w3 + ", " + delay);


    // 使用 FileWriter 追加到文件
    try (FileWriter writer = new FileWriter("output.csv", true)) {
        // 写入数据
        writer.write(output);
        // 换行
        writer.write(System.lineSeparator());
    } catch (IOException e) {
        e.printStackTrace();
    }
}
    private Map<RT, Integer> getOperationsSize(Map<RT, Set<String>> ops) {
        Map<RT, Integer> operationsSize = new TreeMap<>();
        
        // 遍历 ops map，统计每个 RT 类型对应的 Set<String> 的大小
        for (RT op : ops.keySet()) {
            Set<String> resourceSet = ops.get(op);  // 从 ops 获取 Set<String>
            operationsSize.put(op, resourceSet.size());  // 将 Set 的大小存入新的 map
        }
        
        return operationsSize;
    }
    public String selectResourceForRT(RT rt) {
        // 1. 获取所有可以执行当前运算 rt 的资源
        Set<String> eligibleResources = new HashSet<>();
        for (Map.Entry<String, Set<RT>> entry : res.entrySet()) {
            String resource = entry.getKey();
            Set<RT> resourceOps = entry.getValue();
            
            // 如果当前资源可以执行 rt 运算，则加入到 eligibleResources 中
            if (resourceOps.contains(rt)) {
                eligibleResources.add(resource);
            }
        }
    
        // 2. 在 eligibleResources 中找到执行运算最少的资源
        String selectedResource = null;
        int minOperations = Integer.MAX_VALUE;
    
        // 遍历所有符合条件的资源，找到执行运算最少的资源
        for (String resource : eligibleResources) {
            Set<RT> operationsSet = res.get(resource);
            
            // 选择执行运算最少的资源
            if (operationsSet.size() < minOperations) {
                minOperations = operationsSet.size();
                selectedResource = resource;
            }
        }
    
        // 3. 返回选中的资源
        return selectedResource;


    }
    // 将节点存储到 usingMap 中
    public void storeResourceToUsingMap(String resource, int restoreTime) {
        usingMap.put(resource, restoreTime);  // 存储资源并记录恢复时间
        //System.out.printf("source restored in"+restoreTime);
    }
    public void restoreResources(int currentTime) {
        Iterator<Map.Entry<String, Integer>> iterator = usingMap.entrySet().iterator();
        
        while (iterator.hasNext()) {
            Map.Entry<String, Integer> entry = iterator.next();
            String resource = entry.getKey();
            int restoreTime = entry.getValue();
            
            // 如果当前时间 >= 恢复时间，恢复该资源
            if (currentTime >= restoreTime) {
                // 使用 iterator 安全地从 usingMap 中移除
                iterator.remove();
                
                // 获取资源对应的运算集合
                Set<RT> resourceOperations = res.get(resource);
                
                if (resourceOperations != null) {
                    // 恢复到 nowRes 中
                    nowRes.put(resource, resourceOperations);
    
                    // 恢复到 operations 中
                    for (RT rt : resourceOperations) {
                        nowOperations.computeIfAbsent(rt, k -> new HashSet<>()).add(resource);
                    }
                }
            }
        }
    
        // 更新 nowOperationsSize：一次性计算所有操作数
        for (Map.Entry<RT, Set<String>> entry : nowOperations.entrySet()) {
            int size = entry.getValue().size();  // 获取 Set<String> 的大小
            nowOperationsSize.put(entry.getKey(), size);  // 将大小存入 Map<RT, Integer>
        }
    }
    
    
        
    public double scaleScore(double score, double maxScore) {
        // 缩放方法：将所有的 rescore 缩放到最大值为 10
        return Math.min(maxScore/score, 10);  // 确保最大值不超过 10
    }
    public void resetResourcesAndOperations() {
        // 清空现有的 Map
        nowOperationsSize.clear();
        nowRes.clear();
        nowOperations.clear();
        
        
    
        // 对每个资源（Set<RT>）进行深度拷贝并存入 nowRes
        for (Map.Entry<String, Set<RT>> entry : res.entrySet()) {
            Set<RT> copiedSet = new HashSet<>(entry.getValue());  // 使用构造函数进行深拷贝
            nowRes.put(entry.getKey(), copiedSet);  // 将拷贝后的 Set 添加到新的 Map 中
        }
    
        // 将每个 RT 对应的 Set<String> 直接插入到 nowOperations 中
        for (Map.Entry<RT, Set<String>> entry : operations.entrySet()) {
            RT rt = entry.getKey();
            Set<String> resources = entry.getValue();
            nowOperations.put(rt, new HashSet<String>(resources));  // 明确指定类型
        }
        // 重置操作的大小并存入 nowOperationsSize
        for (Map.Entry<RT, Set<String>> entry : nowOperations.entrySet()) {
            int size = entry.getValue().size();  // 获取 Set<String> 的大小
            nowOperationsSize.put(entry.getKey(), size);  // 将大小存入 Map<RT, Integer>
        }
    }
    public void processNodesBeforeTimestep(int currentTimestep) {
        // 遍历所有节点及其对应的上界时间步
        for (Map.Entry<Node, Integer> entry : nodeUpboundTimestepMap.entrySet()) {
            Node node = entry.getKey();
            int upboundTimestep = entry.getValue();
    
            // 如果节点的上界时间步小于当前时间步
            if (upboundTimestep < currentTimestep) {
                // 处理该节点的后继节点
                for (Node successor : node.successors()) {
                    // 移除节点作为后继节点的前继节点
                    successor.remove(node);
                }
            }
        }
    }

    
    









}
    /*
     *处理前的优先级节点调度部分

     *      //寻找最高优先级的节点，调度它
    Node highestScoreNode = null;
    double highestScore = Integer.MIN_VALUE;  // 初始化为最小值

// 遍历 nodePriorities 中的每个条目
    for (Map.Entry<Node, Double> entry : nodePriorities.entrySet()) {
        Node node = entry.getKey();
        double score = entry.getValue();

        // 如果当前 score 大于已有的最高 score，更新最高 score 和对应的 Node
        if (score > highestScore) {
            highestScore = score;
            highestScoreNode = node;
        }
    }
    //当前在将节点进行调动之前已经查阅过资源，最高优先级资源必然可用
    //但是每次调度之前必须再次检查
    // 最终 highestScoreNode 就是 score 最高的那个 Node
        if (highestScoreNode != null) {
            System.out.println("Node with highest score: " + highestScoreNode);
            //资源检查
            if(nowOperationsSize.get(highestScoreNode.getRT())!=0){
                //该节点所需的资源仍然有空闲
                Interval slot=zeroInDegreeQueue.get(highestScoreNode);
                
                schedule.add(highestScoreNode, slot);



                highestScoreNode.markAsProcessed();
                for(Node nd:graph){
                    //该节点将不再是其他节点的前继
                    //必须放在单次循环，所有节点已经处理完毕之后再进行
                    nd.handle(highestScoreNode);
                }
                //资源调度
                String usedres=selectResourceForRT(highestScoreNode.getRT());
                //表明资源何时将重新可用
                resschedule.put(slot.getubound()+1, usedres);
                // 从 operations 中移除选中的资源
                for (Map.Entry<RT, Set<String>> entry : operations.entrySet()) {
                    Set<String> resourceSet = entry.getValue();  // 获取每种运算对应的资源集合
                    resourceSet.remove(usedres);  // 从资源集合中移除被选中的资源
                }

                // 从 nowres 中移除选中的资源
                nowRes.remove(usedres);  // 从资源列表中移除选中的资源
                storeResourceToUsingMap(usedres,slot.getubound()+1);
                nodeCount=nodeCount-1;//该数值为0时，表示调度已经完成

            }
            else{//资源无空闲，移除该节点
                
                nodePriorities.remove(highestScoreNode);

            }



    } else {//表已经调度空了，要timestep+1
        System.out.println("No nodes found.");
        timestep=timestep+1;
    }

     */