package main.java.scheduler;


import java.util.HashMap;
import java.util.Map;

public class LinkScheduler extends Scheduler {

    private Scheduler schedulingStrategy;
    private final int lmax;

    public LinkScheduler(String strategy) {
        if ("ASAP".equalsIgnoreCase(strategy)) {
            this.schedulingStrategy = new ASAP();
            this.lmax = 0;
        } else if ("ALAP".equalsIgnoreCase(strategy)) {
            this.schedulingStrategy = new ALAP();
            this.lmax = 0; // ALAP 默认最大调度时间为0
        } else {
            throw new IllegalArgumentException("Unsupported scheduling strategy");
        }
    }

    // 采用选择的调度策略进行调度
    public Schedule schedule(final Graph sg) {
        // 使用选定策略进行基础调度
        Schedule schedule = schedulingStrategy.schedule(sg);

        // 优化调度，考虑后继节点数、关键路径等因素
        optimizeScheduleBasedOnMetrics(sg, schedule);

        // 返回最终优化后的调度结果
        return schedule;
    }

    // 基于后继节点数和关键路径优化调度
    private void optimizeScheduleBasedOnMetrics(Graph sg, Schedule schedule) {
        Map<Node, Integer> successorsCount = new HashMap<>();
        Map<Node, Integer> criticalPathLength = new HashMap<>();

        // 计算每个节点的后继数量和关键路径长度
        for (Node node : sg) {
            int successors = node.successors().size();
            int pathLength = calculateCriticalPathLength(node);
            successorsCount.put(node, successors);
            criticalPathLength.put(node, pathLength);
        }

        // 优先调度后继节点数多的任务
        for (Node node : sg) {
            if (successorsCount.get(node) > 2) {  // 假设后继节点数大于2的优先调度
                schedule.add(node, new Interval(0, node.getDelay()));
            }
        }

        // 基于关键路径长度进行优先调度
        for (Node node : sg) {
            if (criticalPathLength.get(node) > 3) { // 假设关键路径长度大于3的任务优先调度
                schedule.add(node, new Interval(0, node.getDelay()));
            }
        }
    }

    // 计算节点的关键路径长度
    private int calculateCriticalPathLength(Node node) {
        // 在此可以实现计算关键路径长度的逻辑
        // 例如，关键路径长度是从当前节点到所有叶节点的最长路径
        int maxPathLength = 0;
        for (Node successor : node.successors()) {
            int pathLength = successor.getDelay() + calculateCriticalPathLength(successor);
            maxPathLength = Math.max(maxPathLength, pathLength);
        }
        return maxPathLength;
    }

}
