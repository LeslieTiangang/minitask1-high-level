package main.java.scheduler;

public class GraphAnalyzer {

    // 方法：计算图中的入度、出度和关键路径长度的统计信息
    public static void analyzeGraph(Graph graph) {
        int minInDegree = Integer.MAX_VALUE;
        int maxInDegree = Integer.MIN_VALUE;
        int sumInDegree = 0;
        int countInDegree = 0;
        
        int minOutDegree = Integer.MAX_VALUE;
        int maxOutDegree = Integer.MIN_VALUE;
        int sumOutDegree = 0;
        int countOutDegree = 0;
        
        int minCriticalPathLength = Integer.MAX_VALUE;
        int maxCriticalPathLength = Integer.MIN_VALUE;
        int sumCriticalPathLength = 0;
        int countCriticalPathLength = 0;

        // 遍历图中的每个节点
        for (Node node : graph) {
            // 获取当前节点的入度、出度和关键路径长度
            int inDegree = node.predecessors().size();
            int outDegree = node.successors().size();
            int criticalPathLength = node.getCriticalPathLength();

            // 统计入度的最小值、最大值和平均值
            minInDegree = Math.min(minInDegree, inDegree);
            maxInDegree = Math.max(maxInDegree, inDegree);
            sumInDegree += inDegree;
            countInDegree++;

            // 统计出度的最小值、最大值和平均值
            minOutDegree = Math.min(minOutDegree, outDegree);
            maxOutDegree = Math.max(maxOutDegree, outDegree);
            sumOutDegree += outDegree;
            countOutDegree++;

            // 统计关键路径长度的最小值、最大值和平均值
            minCriticalPathLength = Math.min(minCriticalPathLength, criticalPathLength);
            maxCriticalPathLength = Math.max(maxCriticalPathLength, criticalPathLength);
            sumCriticalPathLength += criticalPathLength;
            countCriticalPathLength++;
        }

        // 输出结果
        System.out.printf("%d, %d, %.2f, %d, %d, %.2f, %d, %d, %.2f,\n", 
       
    minInDegree, maxInDegree, (double) sumInDegree / countInDegree,
    minOutDegree, maxOutDegree, (double) sumOutDegree / countOutDegree,
    minCriticalPathLength, maxCriticalPathLength, (double) sumCriticalPathLength / countCriticalPathLength);
    }
}
      /*
        System.out.printf("In-Degree - Min: %d, Max: %d, Avg: %.2f\n", minInDegree, maxInDegree, (double) sumInDegree / countInDegree);
        System.out.printf("Out-Degree - Min: %d, Max: %d, Avg: %.2f\n", minOutDegree, maxOutDegree, (double) sumOutDegree / countOutDegree);
        System.out.printf("Critical Path Length - Min: %d, Max: %d, Avg: %.2f\n", minCriticalPathLength, maxCriticalPathLength, (double) sumCriticalPathLength / countCriticalPathLength);
        
    }
}
     */
