package main.java.scheduler;
import java.util.*;

public class RandomDotGenerator {

    // 随机生成图的大小
    private static final int MAX_NODES = 10;  // 最大节点数
    private static final int MAX_EDGES = 20;  // 最大边数
    
    public static void main(String[] args) {
        RandomDotGenerator generator = new RandomDotGenerator();
        String dotGraph = generator.generateRandomDot();
        System.out.println(dotGraph);
    }

    // 生成一个随机的 DOT 图
    public String generateRandomDot() {
        Random rand = new Random();
        
        // 随机生成节点数量
        int numNodes = rand.nextInt(MAX_NODES) + 1;  // 1 到 MAX_NODES 个节点
        Set<String> nodes = new HashSet<>();
        
        // 创建节点及其标签
        StringBuilder dotBuilder = new StringBuilder("digraph depgraph {\n");
        for (int i = 0; i < numNodes; i++) {
            String nodeName = "n" + i;
            String label = generateRandomLabel();
            dotBuilder.append(String.format("    %s [label=\"%s\"];\n", nodeName, label));
            nodes.add(nodeName);
        }
        
        // 创建随机连接（边）
        int numEdges = rand.nextInt(MAX_EDGES) + 1;  // 随机生成1到MAX_EDGES条边
        for (int i = 0; i < numEdges; i++) {
            String sourceNode = "n" + rand.nextInt(numNodes);  // 随机选择源节点
            String targetNode = "n" + rand.nextInt(numNodes);  // 随机选择目标节点
            if (!sourceNode.equals(targetNode)) {  // 避免自环
                dotBuilder.append(String.format("    %s -> %s [constraint=false,color=blue,label=\"%d\"];\n",
                        sourceNode, targetNode, rand.nextInt(10) + 1));  // 边的随机标签
            }
        }
        
        dotBuilder.append("}\n");
        
        return dotBuilder.toString();
    }
    
    // 生成一个随机的 label，用于节点
    private String generateRandomLabel() {
        Random rand = new Random();
        int id = rand.nextInt(1000) + 700;  // 生成700到1700之间的ID
        String operation = getRandomOperation();
        return id + ":" + operation;
    }
    
    // 随机选择操作类型
    private String getRandomOperation() {
        String[] operations = {"DMA_STORE", "DMA_LOAD", "IADD", "ISUB", "IFLE", "IFGE", "CMP"};
        Random rand = new Random();
        return operations[rand.nextInt(operations.length)];
    }
}
