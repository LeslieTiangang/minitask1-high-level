import numpy as np
import pandas as pd
from sklearn.model_selection import KFold
from sklearn.preprocessing import StandardScaler
from keras.models import Sequential
from keras.layers import Dense, Dropout
from keras.optimizers import Adam
from keras.callbacks import ReduceLROnPlateau

# 数据准备
data = np.array([
    [0, 2, 1.29, 0, 3, 1.29, 1, 30, 16.38, 2],
    [0, 4, 2.71, 0, 640, 2.71, 1, 315, 158.81, 0],
    [0, 2, 1.44, 0, 32, 1.44, 1, 225, 115.58, 1],
    [0, 3, 1.23, 0, 33, 1.23, 1, 17, 5.45, 1],
    [0, 2, 1.29, 0, 3, 1.29, 1, 30, 16.38, 0],
    [0, 3, 0.98, 0, 18, 0.98, 1, 14, 5.49, 2],
    [0, 2, 1.41, 0, 13, 1.41, 1, 57, 27.75, -2],
    [0, 2, 1.28, 0, 4, 1.28, 1, 23, 9.85, 0],
    [0, 2, 1.39, 0, 16, 1.39, 1, 43, 21.68, 1],
    [0, 3, 1.08, 0, 8, 1.08, 1, 19, 6.01, 2],
    [0, 2, 1.30, 0, 32, 1.30, 1, 76, 37.45, 1],
    [0, 2, 1.25, 0, 8, 1.25, 1, 19, 6.04, 0],
    [0, 3, 1.08, 0, 11, 1.08, 1, 12, 4.38, 1],
    [0, 3, 1.20, 0, 16, 1.20, 1, 15, 7.28, 2],
    [0, 2, 1.13, 0, 27, 1.13, 1, 14, 6.83, 2],
    [0, 3, 1.40, 0, 20, 1.40, 1, 21, 11.17, 0],
    [0, 3, 1.18, 0, 16, 1.18, 1, 14, 6.90, 0],
    [0, 3, 1.21, 0, 16, 1.21, 1, 13, 6.81, 0],
    [0, 3, 1.24, 0, 16, 1.24, 1, 16, 7.63, 1],
    [0, 3, 1.41, 0, 16, 1.41, 1, 14, 6.86, 0],
    [0, 2, 0.82, 0, 4, 0.82, 1, 11, 6.43, 1],
    [0, 2, 1.15, 0, 9, 1.15, 1, 19, 9.97, 0],
    [0, 2, 1.28, 0, 6, 1.28, 1, 21, 11.10, 1],
    [0, 2, 1.14, 0, 9, 1.14, 1, 19, 9.89, 2],
    [0, 2, 1.22, 0, 6, 1.22, 1, 21, 10.83, 2],
    [0, 2, 1.21, 0, 5, 1.21, 1, 21, 10.62, 1]
])

# 输入特征和输出标签
X = data[:, :-1]
y = data[:, -1]

# 数据标准化
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

# KFold交叉验证
kf = KFold(n_splits=5, shuffle=True, random_state=42)

# 定义神经网络模型
def create_model():
    model = Sequential()
    model.add(Dense(64, input_dim=X.shape[1], activation='relu'))
    model.add(Dropout(0.3))  # 添加Dropout层，减少过拟合
    model.add(Dense(32, activation='relu'))
    model.add(Dropout(0.3))  # 添加Dropout层
    model.add(Dense(1, activation='linear'))  # 回归任务，使用线性激活函数
    model.compile(optimizer=Adam(), loss='mean_squared_error')
    return model

# 学习率调度器
lr_scheduler = ReduceLROnPlateau(monitor='loss', factor=0.5, patience=5, min_lr=1e-6)

# K-fold交叉验证训练
for train_index, val_index in kf.split(X_scaled):
    X_train, X_val = X_scaled[train_index], X_scaled[val_index]
    y_train, y_val = y[train_index], y[val_index]
    
    model = create_model()
    model.fit(X_train, y_train, epochs=100, batch_size=8, verbose=0, callbacks=[lr_scheduler])
    
    # 评估模型
    loss = model.evaluate(X_val, y_val)
    print(f"Validation Loss: {loss}")

    # 保存模型
    model.save(f"minitask1.h5")  # 保存模型为H5格式
    print(f"saved as minitask1.h5")
