import pandas as pd

# 读取txt文件
txt_file = 'Training data.txt'  # 修改为你的txt文件路径
df = pd.read_csv(txt_file, delimiter="\t")  # 如果是制表符分隔，可以使用"\t"；如果是其他分隔符，修改此处

# 将其保存为csv文件
csv_file = 'Training data.csv'  # 修改为你想保存的csv文件路径
df.to_csv(csv_file, index=False)  # index=False表示不保存行号
